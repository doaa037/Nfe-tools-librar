# 📚 مكتبة أدوات التعلم عن بُعد
### NFE Tools Library — React Project

> إعداد: د. دعاء مكاري | كلية القاسمي الأكاديمية

مكتبة تفاعلية تضم **46 أداة رقمية** في **8 محاور** لتصميم وتمرير حصص التربية غير المنهجية عبر Zoom.

---

## 🚀 تشغيل المشروع

```bash
# 1. تثبيت المكتبات
npm install

# 2. تشغيل محلياً
npm run dev

# 3. بناء للنشر
npm run build

# 4. معاينة البناء
npm run preview
```

---

## 📁 هيكل الملفات

```
nfe-tools-library/
├── index.html
├── vite.config.js
├── package.json
├── README.md
└── src/
    ├── main.jsx              ← نقطة البداية
    ├── App.jsx               ← المكوّن الرئيسي
    ├── App.module.css
    ├── data/
    │   ├── categories.js     ← تعريف المحاور الثمانية
    │   └── tools.js          ← بيانات الـ 46 أداة
    ├── hooks/
    │   └── useFilter.js      ← منطق البحث والفلترة
    ├── components/
    │   ├── Header.jsx/css    ← الهيدر
    │   ├── FilterBar.jsx/css ← شريط البحث والفلتر
    │   ├── CategorySection.jsx/css ← قسم كل محور
    │   ├── ToolCard.jsx/css  ← بطاقة الأداة
    │   └── EmptyState.jsx/css
    └── styles/
        └── global.css
```

---

## ✨ الميزات

- 🔍 بحث فوري بالاسم والوصف والاستخدام
- 🏷️ فلترة بالمحور (8 محاور)
- 🎞️ تأثيرات حركية عند تحميل البطاقات
- 🆓 مؤشر مجاني / جزئي / مدفوع لكل أداة
- 🔗 رابط مباشر لكل أداة
- 📱 تصميم متجاوب للجوال
- 🌙 هيدر بثيم أسود + ذهبي

---

## 🔧 المتطلبات

- Node.js 18+
- npm 9+
